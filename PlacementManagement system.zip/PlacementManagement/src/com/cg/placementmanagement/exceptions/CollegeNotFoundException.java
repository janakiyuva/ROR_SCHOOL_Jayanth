package com.cg.placementmanagement.exceptions;

public class CollegeNotFoundException extends Exception {

}
