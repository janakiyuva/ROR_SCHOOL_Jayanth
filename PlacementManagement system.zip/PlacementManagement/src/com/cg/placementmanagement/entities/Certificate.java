package com.cg.placementmanagement.entities;

public class Certificate {
private long id;
private int year;
private College college;
}
