package com.cg.placementmanagement.entities;

public class Admin {
private long id;
private String name;
private String password;
}
